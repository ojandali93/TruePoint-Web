import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Reverse Holo TCG — The Collector's Intelligence Platform",
  description:
    "Precision centering analysis, real-time market intelligence, and portfolio management for Pokémon TCG collectors.",
  keywords: [
    "pokemon tcg",
    "card grading",
    "centering tool",
    "psa",
    "collection tracker",
  ],
  icons: {
    icon: "/RH-icon-white.png",
    shortcut: "/RH-icon-white.png",
    apple: "/RH-icon-white.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: ReactNode }>) {
  return (
    <html
      lang='en'
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className='min-h-full flex flex-col'>{children}</body>
    </html>
  );
}
